from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('', views.products, name='products'),
    path('add-to-cart/<int:product_id>/', views.atc,name='add_to_cart'),
    path('atc/', views.cart, name='atc'),
    path('empty_cart/', views.empty_cart, name='empty_cart'),
    path('checkout/', views.chk, name='checkout'),
    path('confirm/', views.confirm_order, name='confirm_order'),
    path('cart/increase/<int:product_id>/', views.increase_quantity, name='increase_quantity'),
    path('cart/decrease/<int:product_id>/', views.decrease_quantity, name='decrease_quantity'),
    path('reset/', views.reset_cart_session),
]
