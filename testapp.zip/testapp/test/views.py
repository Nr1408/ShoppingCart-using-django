from django.shortcuts import render, redirect, get_object_or_404
from .models import Product


# Display all products on homepage
def products(request):
    products = Product.objects.all()
    return render(request, 'card.html', {'products': products})


# Add product to cart
def atc(request, product_id):
    cart = request.session.get('cart', {})  # Ensure cart is a dictionary
    product_id_str = str(product_id)
    cart[product_id_str] = cart.get(product_id_str, 0) + 1
    request.session['cart'] = cart
    return redirect('atc')


# View cart items
def cart(request):
    cart = request.session.get('cart', {})
    product_ids = cart.keys()
    products = Product.objects.filter(id__in=product_ids)

    total_price = 0
    cart_items = []

    for product in products:
        quantity = cart.get(str(product.id), 0)
        subtotal = product.Price * quantity
        total_price += subtotal
        cart_items.append({
            'product': product,
            'quantity': quantity,
            'subtotal': subtotal
        })

    return render(request, 'atc.html', {
        'products': cart_items,
        'total_price': total_price
    })


# Checkout view
def chk(request):
    cart = request.session.get('cart', {})  # { "1": 2, "3": 1 }
    items = []
    total_price = 0

    for product_id, quantity in cart.items():
        try:
            product = Product.objects.get(id=int(product_id))
            subtotal = product.Price * quantity
            items.append({
                'product': product,
                'quantity': quantity,
                'subtotal': subtotal
            })
            total_price += subtotal
        except Product.DoesNotExist:
            continue  # Skip invalid items

    return render(request, 'chk.html', {
        'products': items,
        'total_price': total_price
    })


# Empty the cart
def empty_cart(request):
    request.session['cart'] = {}  # Always a dict, not list
    return redirect('atc')


# Confirm order and clear cart
def confirm_order(request):
    request.session['cart'] = {}
    return render(request, 'confirm_order.html')


# Increase quantity
def increase_quantity(request, product_id):
    cart = request.session.get('cart', {})
    product_id_str = str(product_id)
    cart[product_id_str] = cart.get(product_id_str, 0) + 1
    request.session['cart'] = cart
    return redirect('checkout')


# Decrease quantity
def decrease_quantity(request, product_id):
    cart = request.session.get('cart', {})
    product_id_str = str(product_id)
    if product_id_str in cart:
        if cart[product_id_str] > 1:
            cart[product_id_str] -= 1
        else:
            del cart[product_id_str]
    request.session['cart'] = cart
    return redirect('checkout')

def reset_cart_session(request):
    request.session.flush()  # This clears all session data (cart, login state, etc.)
    return redirect('products')

