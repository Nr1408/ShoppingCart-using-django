from django.db import models

class Product(models.Model):
    Name = models.CharField(max_length=200)
    Product_type = models.CharField(max_length=25)
    Price = models.IntegerField()
    Image_url = models.CharField(max_length=2500)
    
